from evaluation import evaluate
import numpy as np

# Test with some sample anomaly data
anomalies = np.array([False, False, True, False, False, True, False, False, False, False])
accuracy, collision_reduction, speed_improvement = evaluate(anomalies)

print("=== Evaluation Results ===")
print(f"Anomaly Accuracy: {accuracy*100:.1f}%")
print(f"Collision Reduction: {collision_reduction*100:.0f}%")
print(f"Speed Improvement: {speed_improvement*100:.0f}%")
