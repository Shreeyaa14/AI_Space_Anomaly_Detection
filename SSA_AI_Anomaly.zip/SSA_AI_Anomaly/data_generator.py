# data_generator.py
import numpy as np
import os

def generate_orbit_data(n=2000):
    """
    Generate orbital data with injected anomalies.
    
    Args:
        n (int): Number of data points to generate
        
    Returns:
        numpy.ndarray: Array of shape (n, 4) containing [x, y, vx, vy] data
    """
    print(f"Generating {n} data points...")
    t = np.linspace(0, 100, n)
    x = 7000*np.cos(0.01*t)
    y = 7000*np.sin(0.01*t)
    vx = -70*np.sin(0.01*t)
    vy = 70*np.cos(0.01*t)

    data = np.vstack([x, y, vx, vy]).T

    # Inject anomalies
    print("Injecting anomalies...")
    for i in range(1600, 1700):
        data[i] += np.random.normal(0, 300, 4)

    return data

def save_data(data, filename='orbit_data.npy'):
    """Save the generated data to a file."""
    try:
        np.save(filename, data)
        print(f"Data successfully saved to {os.path.abspath(filename)}")
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False

if __name__ == "__main__":
    # Generate the data
    orbit_data = generate_orbit_data()
    
    # Save the data
    save_data(orbit_data)
    
    # Print some basic info
    print("\nData generation complete!")
    print(f"Generated data shape: {orbit_data.shape}")
    print(f"First 5 data points:\n{orbit_data[:5]}")
